import org.apache.pdfbox.multipdf.Splitter;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
//import org.apache.pdfbox.pdmodel.common.PDPageRange;
//import org.apache.pdfbox.text.PDFTextStripper;

import java.io.File;
import java.io.IOException;
import java.util.List;

class MainClass {

    public static void main(String[] args) throws IOException {
        File oldFile = new File("C:\\PDF\\compnetworks.pdf"); // Replace with your input PDF file path
        PDDocument document = PDDocument.load(oldFile);

        File newFileDestination = new File("C:\\PDF\\demo");
        newFileDestination.mkdir();

        Splitter splitter = new Splitter();
        splitter.setStartPage(20);
        splitter.setEndPage(50);
        List<PDDocument> splitPages = splitter.split(document);

        PDDocument newDoc = new PDDocument();
        for (PDDocument mydoc : splitPages) {
            newDoc.addPage(mydoc.getPage(0));
        }
        newDoc.save(newFileDestination + "\\split.pdf");
        newDoc.close();
        System.out.println("PDF Created");
    }
}
////        String outputFilePath = "C:\\PDF\\demo"; // Replace with your desired output PDF file path
////        int startPage = 20; // Start page number (inclusive)
////        int endPage = 50; // End page number (inclusive)
////
////        try {
////            PDDocument document = PDDocument.load(new File(inputFilePath));
////
////            // Create a new document to store the extracted pages
////            PDDocument extractedDocument = new PDDocument();
//
//            for (int pageNum = startPage; pageNum <= endPage; pageNum++) {
//                extractedDocument.addPage(document.getPage(pageNum - 1));
//            }
//
//            extractedDocument.save(outputFilePath);
//            extractedDocument.close();
//            document.close();
//
//            System.out.println("Pages " + startPage + " to " + endPage + " extracted to " + outputFilePath);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//}
